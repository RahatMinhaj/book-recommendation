package com.minhaz.bookrecommendation.controller;

import com.minhaz.bookrecommendation.dto.JWTAuthenticationResponse;
import com.minhaz.bookrecommendation.dto.RefreshTokenRequest;
import com.minhaz.bookrecommendation.entity.AppUser;
import com.minhaz.bookrecommendation.repository.AppUserRepository;
import com.minhaz.bookrecommendation.service.JWTService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController{

    private final AppUserRepository appUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JWTService jwtService;

    @PostMapping("/create")
    public ResponseEntity<AppUser> create(@RequestBody AppUser appUser){
        appUser.setAppPassword(passwordEncoder.encode(appUser.getPassword()));
        appUser = appUserRepository.save(appUser);
        return ResponseEntity.ok(appUser);
    }

    @PostMapping("/login")
    public ResponseEntity<JWTAuthenticationResponse> signIn(@RequestBody AppUser appUser){
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(appUser.getUsername(), appUser.getAppPassword()));
        AppUser user = appUserRepository.findByUserName(appUser.getUsername()).orElseThrow(()-> new IllegalArgumentException("invalid email or password"));
        var jwt = jwtService.generateToken(user);
        var refreshToken = jwtService.generateRefreshToken(new HashMap<>(), user);
        JWTAuthenticationResponse response = new JWTAuthenticationResponse();
        response.setToken(jwt);
        response.setRefreshToken(refreshToken);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/refresh")
    public ResponseEntity<JWTAuthenticationResponse> refreshTokenRequest(@RequestBody RefreshTokenRequest refreshTokenRequest){
        String userName = jwtService.extractUserName(refreshTokenRequest.getToken());
        AppUser user = appUserRepository.findByUserName(userName).orElseThrow();
        if(jwtService.isTokenValid(refreshTokenRequest.getToken(), user)){
            var jwt = jwtService.generateToken(user);
            JWTAuthenticationResponse response = new JWTAuthenticationResponse();
            response.setToken(jwt);
            response.setRefreshToken(refreshTokenRequest.getToken());
            return ResponseEntity.ok(response);
        }
        return null;
    }
}
