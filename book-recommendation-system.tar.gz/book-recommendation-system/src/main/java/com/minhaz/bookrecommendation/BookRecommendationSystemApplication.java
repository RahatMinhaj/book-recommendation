package com.minhaz.bookrecommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookRecommendationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookRecommendationSystemApplication.class, args);
	}
}
