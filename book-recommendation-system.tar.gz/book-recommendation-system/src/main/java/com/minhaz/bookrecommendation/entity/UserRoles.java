package com.minhaz.bookrecommendation.entity;

public enum UserRoles {
    PRODHAN,
    SHADHARON;
}
