package com.minhaz.bookrecommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookRecommendationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
